# Smart_India_Hackthon
In the Smart India Hackthon my team is doing work in Smart automation in post office services
